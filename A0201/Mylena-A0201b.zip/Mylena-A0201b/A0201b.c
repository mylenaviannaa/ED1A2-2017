#include <stdio.h>
#include <stdlib.h>

int g1,g2,g3;

void processaNumeros (int n1,int n2,int*n3){
    n1 = n1 * 10;
    n2 = n2 * 100;
    *n3 = (*n3) * 1000;
    
    printf("\n Em processaNumeros (g1 -> n1) vale: %i",n1); 
    printf("\n Em processaNumeros (g2 -> n2) vale: %i",n2); 
    printf("\n Em processaNumeros (g3 <-> n3) vale: %i",&n3); 
}

int main(){
    g1 = 1;
    g2 = 2;
    g3 = 3;
    
    processaNumeros(g1,g2,&g3);
    
     printf("\n O valor de g1 apos processaNumeros e %i",g1); 
     printf("\n O valor de g2 apos processaNumeros e %i",g2); 
     printf("\n O valor de g3 apos processaNumeros e %i",g3); 
    
    
}
#include <stdio.h>
#include <stdlib.h>

int g1,g2,g3;

int soma(int n1,int n2){
    int r;
    
    r = n1 + n2;
    return r ;
}

int main (){
  printf("A soma de 10 com 20 e %i",soma(10,20));

  g1 = 100;
  g2 = 200;
  
  printf("\n A soma da global 1 com a global 2 e %i",soma(g1,g2));
  
  g3 = soma(1000,2000);
  
  printf("\n A soma de 1000 com 2000 (g3) e %i",g3);
}
